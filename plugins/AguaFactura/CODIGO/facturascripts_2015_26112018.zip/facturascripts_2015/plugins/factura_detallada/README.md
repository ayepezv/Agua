# factura_detallada
Añade un nuevo formato de impresión de facturas y albaranes de cliente a FacturaScripts.
Permite añadir traducciones para estos formatos.

https://www.facturascripts.com/plugin/factura_detallada