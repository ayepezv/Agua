# backup_restore

* Permite hacer copias de seguridad de nuestra base de datos, descargarlas, restaurarlas y subirlas en otras instalaciones.
* Permite hacer copias de seguridad de nuestra instalación de FacturaScripts (todos sus archivos), descargarlas, restaurarlas y subirlas en otras instalaciones.
https://www.facturascripts.com/plugin/backup_restore

Este plugin se ha desarrollado de forma comunitaria para uso en FacturaScripts.

Puedes usar la libreria DatabaseManager sin FacturaScripts si necesitas una libreria sencilla para hacer backups de MySQL y PostgreSQL, esta librería esta en la carpeta vendor\FacturaScripts

NOTA PARA PARTNERS: Hay constantes en functions.php que se pueden modificar o incluir en el config.php de las instalaciones para limitar el funcionamiento.