<?php
define('FS_DB_TYPE', 'POSTGRESQL');
define('FS_DB_HOST', 'localhost');
define('FS_DB_PORT', '5434');
define('FS_DB_NAME', 'agua_batan');
define('FS_DB_USER', 'postgres');
define('FS_DB_PASS', 'andres1979');
define('FS_CACHE_HOST', 'localhost');
define('FS_CACHE_PORT', '11211');
define('FS_CACHE_PREFIX', 'hQy9nObL_');
define('FS_TMP_NAME', '8Tb39HBgYouKEk1DA0Wy/');
define('FS_COOKIES_EXPIRE', 604800);
define('FS_ITEM_LIMIT', 50);
define('FS_DB_HISTORY', FALSE);
define('FS_DEMO', FALSE);
define('FS_DISABLE_MOD_PLUGINS', FALSE);
define('FS_DISABLE_ADD_PLUGINS', FALSE);
define('FS_DISABLE_RM_PLUGINS', FALSE);
